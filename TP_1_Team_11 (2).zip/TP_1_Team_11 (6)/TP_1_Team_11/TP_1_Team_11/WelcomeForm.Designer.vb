﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtTeam11Username = New System.Windows.Forms.TextBox()
        Me.txtTeam11Password = New System.Windows.Forms.TextBox()
        Me.lblTeam11Username = New System.Windows.Forms.Label()
        Me.lblTeam11Password = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtTeam11Username
        '
        Me.txtTeam11Username.Location = New System.Drawing.Point(120, 150)
        Me.txtTeam11Username.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTeam11Username.Name = "txtTeam11Username"
        Me.txtTeam11Username.Size = New System.Drawing.Size(199, 26)
        Me.txtTeam11Username.TabIndex = 0
        '
        'txtTeam11Password
        '
        Me.txtTeam11Password.Location = New System.Drawing.Point(128, 265)
        Me.txtTeam11Password.Margin = New System.Windows.Forms.Padding(2)
        Me.txtTeam11Password.Name = "txtTeam11Password"
        Me.txtTeam11Password.Size = New System.Drawing.Size(199, 26)
        Me.txtTeam11Password.TabIndex = 1
        '
        'lblTeam11Username
        '
        Me.lblTeam11Username.AutoSize = True
        Me.lblTeam11Username.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTeam11Username.Location = New System.Drawing.Point(124, 101)
        Me.lblTeam11Username.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTeam11Username.Name = "lblTeam11Username"
        Me.lblTeam11Username.Size = New System.Drawing.Size(91, 20)
        Me.lblTeam11Username.TabIndex = 2
        Me.lblTeam11Username.Text = "Username"
        '
        'lblTeam11Password
        '
        Me.lblTeam11Password.AutoSize = True
        Me.lblTeam11Password.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTeam11Password.Location = New System.Drawing.Point(124, 227)
        Me.lblTeam11Password.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.lblTeam11Password.Name = "lblTeam11Password"
        Me.lblTeam11Password.Size = New System.Drawing.Size(86, 20)
        Me.lblTeam11Password.TabIndex = 3
        Me.lblTeam11Password.Text = "Password"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.TP_1_Team_11.My.Resources.Resources.image
        Me.PictureBox1.Location = New System.Drawing.Point(638, 30)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(2)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(621, 410)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(120, 395)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(199, 45)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Enter"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1304, 497)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.lblTeam11Password)
        Me.Controls.Add(Me.lblTeam11Username)
        Me.Controls.Add(Me.txtTeam11Password)
        Me.Controls.Add(Me.txtTeam11Username)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Form1"
        Me.Text = "Welcome"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtTeam11Username As TextBox
    Friend WithEvents txtTeam11Password As TextBox
    Friend WithEvents lblTeam11Username As Label
    Friend WithEvents lblTeam11Password As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Button1 As Button
End Class
